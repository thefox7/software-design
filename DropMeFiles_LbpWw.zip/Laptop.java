package models;

public class Laptop extends Product {
    public Laptop() {
        super("Laptop", 999.99);
    }
}
