package models;

public class Smartphone extends Product {
    public Smartphone() {
        super("Smartphone", 499.99);
    }
}
